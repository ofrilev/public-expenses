package uploadnewscrapedfile

import (
	"handleNewScrape/transactionObject"
	"handleNewScrape/uploadNewScrapedFile/utils"
)

func UploadNewScrapedFile(pf []*transactionObject.Transaction)error {	
	utils.UpdateExpenses(pf)
	return nil
}