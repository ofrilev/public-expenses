package utils

import (
	"fmt"
	"handleNewScrape/transactionObject"
	"log"

	gormdbmodule "newgo/gormDbModule"
	"newgo/models"
	"sync"
	"time"
)

func UpdateExpenses(tr []*transactionObject.Transaction) {
	transactionObject.InsertTransaction(tr)
	var ex []*models.Expense
	for _,t := range tr { 
		ex = append(ex, transactionObject.ConvertToExpense(t))
	}
	getCategories(ex, 5)
	updateCategories(tr)
}

func updateDbExpense(ta *models.Expense) error {
    result := gormdbmodule.DB.Model(&models.Expense{}).
        Where("amount = ? AND date = ? AND business_name = ?", ta.Amount, ta.Date, ta.BusinessName).
        Update("category", ta.CategoryID)
			if result.RowsAffected == 0 {
				log.Fatalf("No rows were inserted for expense:bname-%v,amount-%v,date-%v", ta.BusinessName, ta.Amount, ta.Date) // consider returning the error instead
			}
    return result.Error
}

func updateCategories(tr []*transactionObject.Transaction) {
	var wg  sync.WaitGroup
	concurrencyLimit := make(chan struct{}, 5)
	for _, tran := range tr {
		wg.Add(1)
		go func(ta *transactionObject.Transaction) {
			
			defer wg.Done()
			// Only proceed if the category is set
			if ta.Category != 47 && ta.Category != 0 {
				concurrencyLimit <- struct{}{}
				parsedDate, err := time.Parse("2006-01-02", ta.Date)
				if err != nil {
					log.Fatalf("failed to parse date: %v", err)
					return
				}
				ex :=  &models.Expense{
					BusinessName: "",
					Amount:       ta.Amount,
					Date:         parsedDate,
					CardNumber:   ta.CardNumber,
					CategoryID:   ta.Category,
				}
				err = updateDbExpense(ex)
				// Build and execute your update query here
				// query := fmt.Sprintf("UPDATE expenses SET category=%v WHERE amount=%v and date= TO_DATE('%v','DD-MM-YYYY') and business_name='%v'",ta.Category, ta.Amount, ta.Date, ta.Business_name)
				// fmt.Println(query)
				// res, err := dbmodule.DB.Exec(query)
				if err != nil {
					fmt.Println(err)
					log.Fatalf("failed to update expense with error: %v", err)
				}
				
				<-concurrencyLimit
			}
		}(tran)
	}
	func(){
		wg.Wait()
	}()
}
