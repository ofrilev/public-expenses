package utils

import (
	gormdbmodule "newgo/gormDbModule"
	"newgo/models"
	"sync"
	"time"

	"gorm.io/gorm"
)

func getCategories(exparr []*models.Expense, interval int) (time.Duration, error) {
	start := time.Now()
	var wg sync.WaitGroup
	errChan := make(chan error, 1)
	concurrencyLimit := make(chan struct{}, interval) // Limit to interval concurrent goroutines

	for _, exp := range exparr {
		wg.Add(1)
		go func(exp *models.Expense) {
			defer wg.Done()

			concurrencyLimit <- struct{}{}
			defer func() { <-concurrencyLimit }()

			var category models.Category
			
			if err := gormdbmodule.DB.Where("business_name LIKE ?",exp.BusinessName).First(&category).Error; err != nil {
				if err != gorm.ErrRecordNotFound {
					select {
					case errChan <- err:
					default:
					}
				}
				return
			}
			exp.CategoryID = *&category.ID
		}(exp)
	}

	go func() {
		wg.Wait()
		close(errChan)
	}()

	if err, ok := <-errChan; ok {
		return 0, err
	}
	return time.Since(start), nil
}