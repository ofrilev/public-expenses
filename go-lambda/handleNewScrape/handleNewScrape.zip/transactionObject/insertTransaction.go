package transactionObject

import (
	"errors"
	"log"
	gormdbmodule "newgo/gormDbModule"
	"newgo/models"
	"time"
)

func ConvertToExpense(t *Transaction) *models.Expense {
	parsedDate, err := time.Parse("02-01-2006", t.Date)
	if err != nil {
		log.Println("Error parsing date:", err)
	}
	if err != nil{
		log.Printf("failed to parse date with err:%v",err)
	}
    return &models.Expense{
        BusinessName: t.Business_name,
        Date:         parsedDate, // Convert to time.Time if needed
        Amount:       t.Amount,
        CardNumber:   t.CardNumber,
        CategoryID:   t.Category,
    }
}

func InsertTransaction(trans []*Transaction) error {
    if len(trans) == 0 {
        return nil
    }

    var expenses []*models.Expense
    for _, tran := range trans {
        expenses = append(expenses, ConvertToExpense(tran))
    }

	result := gormdbmodule.DB.Omit("CategoryID").Create(&expenses)
    if result.Error != nil {
        log.Println("Error occurred while inserting transactions:", result.Error)
        return result.Error
    }

    if result.RowsAffected == 0 {
        log.Println("No rows were inserted")
        return errors.New("no rows were inserted")
    }

    return nil
}