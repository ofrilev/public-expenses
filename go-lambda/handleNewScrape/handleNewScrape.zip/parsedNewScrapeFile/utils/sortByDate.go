package utils

import (
	"handleNewScrape/transactionObject"
	"log"
	"sort"
	"time"
)

func SortStructsByDate(trr []* transactionObject.Transaction) {
	// Define a custom sort function
	sort.Slice(trr, func(i, j int) bool {
		dateI, err := time.Parse("02-01-2006", trr[i].Date)
		if err != nil {
			log.Fatalf("Invalid date format: %v", err)
		}

		dateJ, err := time.Parse("02-01-2006", trr[j].Date)
		if err != nil {
			log.Fatalf("Invalid date format: %v", err)
		}
		return dateI.Before(dateJ)
	})
}
