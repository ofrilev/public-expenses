package utils

import "handleNewScrape/transactionObject"

func FindSliceIndex(trarr []*transactionObject.Transaction, lastexpense transactionObject.Transaction) int {
	ldate := parseDate(lastexpense.Date)
	for i, e := range trarr {
		edate := parseDate(e.Date)

		if ldate.After(edate) {
			continue
		}
		if ldate.Before(edate) && len(trarr) > i+2 || (e.Business_name == lastexpense.Business_name &&
			(i+1 >= len(trarr) || trarr[i+1].Business_name != lastexpense.Business_name)) {
			return i + 1
		}
	}
	return 0
}
