package parsednewscrapefile

import (
	"handleNewScrape/parsedNewScrapeFile/utils"
	"handleNewScrape/transactionObject"
	"log"
	"os"
)
func Parsednewscrapefile(f *os.File, fn string, le transactionObject.Transaction)([]*transactionObject.Transaction, error) {	
	if utils.IsFstFileDateGreaterThenSnd(fn, le.Date) {
		r := transactionObject.ReadExcelFromFile(f)
		trarr := transactionObject.GetTransactionObj(r)
		utils.SortStructsByDate(trarr)
		si := utils.FindSliceIndex(trarr, le)
		sd := trarr[si:]
		if len(sd)  > 0 {
			return sd, nil
		}
	}
	log.Printf("file:%v not have any new expense", fn)
	return nil, nil
}