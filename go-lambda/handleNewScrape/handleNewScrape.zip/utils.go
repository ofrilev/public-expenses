package main

import (
	"handleNewScrape/transactionObject"
	"log"
	gormdbmodule "newgo/gormDbModule"
	"newgo/models"
	"os"
	"strings"
)


func getLastExpense() (transactionObject.Transaction, error) {
	var exp models.Expense
	if err := gormdbmodule.DB.Order("date DESC, id DESC").First(&exp).Error; err != nil {
		log.Fatalf("failed to get last expense with err: %s", err)
		return transactionObject.Transaction{}, err
	}
	var res = transactionObject.Transaction{
		Business_name: exp.BusinessName, 
		Date:         exp.Date.Format("02-01-2006"), // Format the date as "DD-MM-YYYY"
		Amount:       exp.Amount,
	}
	return res, nil

}

func getFileName(fe *os.File) string {
	parts := strings.Split(fe.Name(), "/")
	return parts[len(parts)-1]
}

